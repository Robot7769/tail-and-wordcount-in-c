/**
 * @file htab_for_each.c
 * @author Jan Škrabal (xskrab12)-FIT
 * @brief IJC-DU2 Projde všechny záznamy a zavolá na ně funkci f
 * @date 2022-03-23
 * 
 * @copyright Copyright (c) 2022
 * 
 */

#include "htab_struct.h"
#include "error.h"

void htab_for_each(const htab_t * t, void (*f)(htab_pair_t *data)) {
    if (t == NULL) {
        error_exit("htab_t * t je NULL, modul htab_for_each",0);
    }
    if (t->arr_size == 0 || t->arr_ptr == NULL) {
        return;
    }
    size_t j = 0;
    for (size_t i = 0; i < t->arr_size; i++) { //! potřeba opravit, pomocí klíče nemusím procházet celou strukturu
        htab_item_t *tmp = t->arr_ptr[i];
        //printf("each-1\n");
        if (t->arr_ptr[i] != NULL) {
            //printf(" --each-- ");
            for (; j < t->size; j++) {
                //printf("each00\n");
                if (tmp->data != NULL) {
                    //printf("each01\n");
                    f(tmp->data);
                }
                if (tmp->next != NULL) {
                    tmp = tmp->next;
                } else {
                    break;
                }
            }
        }
    }
    return;
}